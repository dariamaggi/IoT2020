package unipi.iot;

import org.eclipse.californium.core.CoapServer;

public class Server extends CoapServer {

	public void startServer() {
		System.out.println("Start");
		this.add(new RegistrationResource("registration"));
		this.start();
	}
}
