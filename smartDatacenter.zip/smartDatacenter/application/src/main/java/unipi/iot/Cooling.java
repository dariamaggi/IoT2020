package unipi.iot;

public class Cooling extends Resource {

	public Cooling(String path, String address) {
		super(path, address);
		// TODO Auto-generated constructor stub
	}

	private Boolean status = false;

	
		public Boolean checkActive(){
			return this.status;
		}

		public void setStatus(Boolean status){
			this.status = status;
		}
}
