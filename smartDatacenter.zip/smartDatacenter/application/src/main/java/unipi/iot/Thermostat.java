package unipi.iot;

import java.util.ArrayList;

public class Thermostat extends Resource {
	private  ArrayList<String> temperatures;
	public Thermostat(String path, String address) {
		super(path, address);
	}
	

}
